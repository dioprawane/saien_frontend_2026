1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/0w~awiv7n~fop.js","/_next/static/chunks/00-csyj9a6t-x.js"],"ClientSegmentRoot"]
3:I[8374,["/_next/static/chunks/0w~awiv7n~fop.js","/_next/static/chunks/00-csyj9a6t-x.js","/_next/static/chunks/0tqs1q_b.~1kk.js"],"default"]
4:I[39756,["/_next/static/chunks/0w~awiv7n~fop.js","/_next/static/chunks/00-csyj9a6t-x.js"],"default"]
5:I[37457,["/_next/static/chunks/0w~awiv7n~fop.js","/_next/static/chunks/00-csyj9a6t-x.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/0tqs1q_b.~1kk.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"TpD_-fdlKYI0-zwsAewXt"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
