1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0w~awiv7n~fop.js","/_next/static/chunks/00-csyj9a6t-x.js"],"default"]
3:I[37457,["/_next/static/chunks/0w~awiv7n~fop.js","/_next/static/chunks/00-csyj9a6t-x.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"TpD_-fdlKYI0-zwsAewXt"}
