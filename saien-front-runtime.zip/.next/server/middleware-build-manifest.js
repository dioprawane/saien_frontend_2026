globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/TpD_-fdlKYI0-zwsAewXt/_buildManifest.js",
    "static/TpD_-fdlKYI0-zwsAewXt/_ssgManifest.js",
    "static/TpD_-fdlKYI0-zwsAewXt/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/0f_6_nfem~mpr.js",
    "static/chunks/14twbv~x5-78j.js",
    "static/chunks/0qtz4meecy2cb.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-084x1ax1bgpf3.js"
  ]
};
